<?php 

session_start();

//check whether any products are in cart or not

if(!empty ($_SESSION['cart'])  && isset($_POST['checkout']))
{
    //let user in

}
//send the user to home page
else
{
    header('location: index.php');
}
?>

<html>
    <head>
        <title>E-painting</title>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"/>
        <script src="https://kit.fontawesome.com/c4a594ff55.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="first.css">
    </head>
    <body>
        <section id = "header">
            <a href="#"> <img src="logo/download (2).png" class = "logo" alt="" style="max-width: 20%"></a>
            <div>
                <ul id="navbar"> 
                    <li><a  href="index.php" >Home</a></li>
                    <li><a  href="shop.html">Shop</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a  href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.html">login</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </section>

        <div class="form-box">
            <h2 style="font-size: 30px; text-align: center; ">Checkout</h2>
            <!-- <div class="button-box">
                    <div id="btn"></div>
                        <button type="button" class="login" id="login-btn">Log in</button>
                        <button type="button" class="login" id="signup-btn">Sign up</button>
            </div> -->
            <!-- <div class="social-icons">
                <i class="fa-brands fa-facebook"></i>
                <i class="fa-brands fa-google"></i>
                <i class="fa fa-instagram" aria-hidden="true"></i>
            </div> -->
            <form id="login" class="input-group" method="post" action="server/place_order.php">
                <input  type="text" class="input-field" placeholder="name" name="name">
                <input  type="email" class="input-field" placeholder="e-mail" name="e-mail">
                <input  type="text" class="input-field" placeholder="phone" name="phone">
                <input  type="text" class="input-field" placeholder="city" name="city">
                <input  type="text" class="input-field" placeholder="address" name="address">
                <!-- <div>
                    <input type="checkbox" class="check-box"><span>Remember password</span>
                </div> -->
                <p>Total: Rs.<?php echo  $_SESSION['total']; ?></p>
                <div class="place_order">
                    
                    <button type="submit" class="button" name="place_order">place_order</button>
                </div>
            </form>
            <!-- <form id="signup" class="input-group">
                <input type="text" class="input-field" placeholder="Your e-mail">
                <input type="text" class="input-field" placeholder="password">
                <div>
                    <input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>
                </div>
                <button type="button" class="normal">Sign up</button>
            </form> -->
        </div>

        

        <footer class="section-p1">
            <div class="col">
                <a href="#"> <img class = "logo" src="logo/download (2).png" class = "logo" alt="" style="max-width: 15%"></a>
                <h4>Contact</h4>
                <p><strong>Phone: </strong> +61 1300 002 340</p>
                <p><strong>Email: </strong> info@epainting.com.lk</p>
                <div class="follow">
                    <h4>follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                        <i class="fa fa-pinterest-square" aria-hidden="true"></i>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col-flex">
                <div class="col">
                    <h4>About</h4>
                    <a href="#" onclick="window.location.href='about.html';">About us</a>
                    <a href="#">Delivery & Refunds</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms & conditions</a>
                    <a href="#" onclick="window.location.href='contact.html';">Contact us</a>
                </div>
                <div class="col">
                    <h4>My Account</h4>
                    <a href="#" onclick="window.location.href='login.html';">Login</a>
                    <a href="#" onclick="window.location.href='cart.html';">View Cart</a>
                    <a href="#">Help</a>
                </div>
                <div class="col install">
                   <h4>Secured Payment Gateways</h4>
                   <img src="logo/pay4-removebg-preview.png" alt="" style="max-width: 30%">
                   
                </div>
            </div>
        </footer>
    </body>
</html>