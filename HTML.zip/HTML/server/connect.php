 <?php 
  
  $conn = mysqli_connect("localhost", "root", "", "epainting",3306);
//           or die("couldn't connect to database!");
//   $conn ->  close();
 ?>