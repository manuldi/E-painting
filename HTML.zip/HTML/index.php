<html>
    <head>
        <title>E-painting</title>
        <script src="https://kit.fontawesome.com/c4a594ff55.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="first.css">
    </head>
    <body>
        <section id = "header">
            <a href="#"> <img src="logo/download (2).png" class = "logo" alt="" style="max-width: 20%"></a>
            <div>
                <ul id="navbar"> 
                    <li><a  class="active" href="first.html" >Home</a></li>
                    <li><a href="shop.html">Shop</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </section>

        <section class="hero">
            <div class="left">
                <img src="logo/main.jpg" alt="main-image">
            </div>
            <div class="right">
                <div>
                    <h1>Get free shipping <br> <span>on all orders over <span>Rs.10000</span></span></h1>
                    <p>If you order before 31 st of Octomber</p>
                    <button style="text-align: right">Shop Now</button>
                </div>
            </div>
        </section>

        <section id="feature" class="section-p1">
            <div class="fe-box">
                <img src="logo/service11.png"/>
                <h6>Free shipping</h6>
            </div>
            <div class="fe-box">
                <img src="logo/service2-transformed.png"/>
                <h6>Online order</h6>
            </div>
            <div class="fe-box">
                <img src="logo/service3-removebg-preview.png"/>
                <h6>Save money</h6>
            </div>
            <div class="fe-box">
                <img src="logo/service42.jpg"/>
                <h6>Promotions</h6>
            </div>
            <div class="fe-box">
                <img src="logo/service52.jpg"/>
                <h6>Happy sell</h6>
            </div>
            <div class="fe-box">
                <img src="logo/service7-removebg-preview.png"/>
                <h6>24/7 Support</h6>
            </div>
        </section>

        <section id="product1" class="section-p1">
            <h2>Popular categories</h2>
            <div class="pro-container">
                <div class="pro">
                    <img src="products/product1.webp" alt="">
                    <div class="des">
                        <h5>Floral art</h5>
                    </div>
                </div>
                <div class="pro">
                    <img src="products/product7.jpg" alt="">
                    <div class="des">
                        <h5>Landscape & Nature</h5>
                    </div>
                </div>
                <div class="pro">
                    <img src="products/product3.jpg" alt="">
                    <div class="des">
                        <h5>Animal & birds</h5>
                    </div>
                </div>
                <div class="pro">
                    <img src="products/product4.jpg" alt="">
                    <div class="des">
                        <h5>Portraits</h5>
                    </div>
                </div>
                <div class="pro">
                    <img src="products/product5.jpg" alt="">
                    <div class="des">
                        <h5>Abstract art</h5>
                    </div>
                </div>
                <div class="pro">
                    <img src="products/product6.jpg" alt="">
                    <div class="des">
                        <h5>Framed prints</h5>
                    </div>
                </div>
            </div>
        </section>

        <section id="product2" class="section-p1">
            <h2>New arrivals</h2>
            <div class="pro-container">
                <div class="pro">
                    <img src="products/product10.jpg" alt="">
                    <div class="des">
                        <h5>Gift Stack</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.9999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product11.jpg" alt="">
                    <div class="des">
                        <h5>Ready To Bloom</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.7499</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product15.webp" alt="">
                    <div class="des">
                        <h5>Hidden Fairy Of Colors</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.12999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product16.jpg" alt="">
                    <div class="des">
                        <h5>Winter Lake</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.8999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product17.jpg" alt="">
                    <div class="des">
                        <h5>Follow the light</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.14999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product18.webp" alt="">
                    <div class="des">
                        <h5>Bridge To Nowhere</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.7499</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product19.jpg" alt="">
                    <div class="des">
                        <h5>Rainbow Flowers</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.4999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product20.jpg" alt="">
                    <div class="des">
                        <h5>Aqua Victory</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>Rs.9999</h4>
                    </div>
                    <a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                </div>
            </div>
        </section>

        <section id ="newsletter" class="section-p1">
            <div class = "newstext">
                <h4>Sign up for Free</h4>
                <p>Get E-mail updates about latest shop and <span> special offers.</span></p>
            </div>
            <div class ="form">
                <!--<input type = "text" placeholder="Your e-mail address">-->
                <button class="normal" onclick="window.location.href='login.html';">Sign up</a></button>
            </div>
        </section>

        <footer class="section-p1">
            <div class="col">
                <a href="#"> <img class = "logo" src="logo/download (2).png" class = "logo" alt="" style="max-width: 15%"></a>
                <h4>Contact</h4>
                <p><strong>Phone: </strong> +61 1300 002 340</p>
                <p><strong>Email: </strong> info@epainting.com.lk</p>
                <div class="follow">
                    <h4>follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                        <i class="fa fa-pinterest-square" aria-hidden="true"></i>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col-flex">
                <div class="col">
                    <h4>About</h4>
                    <a href="#" onclick="window.location.href='about.html';">About us</a>
                    <a href="#">Delivery & Refunds</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms & conditions</a>
                    <a href="#" onclick="window.location.href='contact.html';">Contact us</a>
                </div>
                <div class="col">
                    <h4>My Account</h4>
                    <a href="#" onclick="window.location.href='login.html';">Login</a>
                    <a href="#" onclick="window.location.href='cart.html';">View Cart</a>
                    <a href="#">Help</a>
                </div>
                <div class="col install">
                   <h4>Secured Payment Gateways</h4>
                   <img src="logo/pay4-removebg-preview.png" alt="" style="max-width: 30%">
                   
                </div>
            </div>
        </footer>
        <script src="first.js"></script>
    </body>
    
</html>