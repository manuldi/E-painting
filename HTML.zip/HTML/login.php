<?php 
    session_start();

    include('server/connect.php');

    if (isset($_SESSION['logged in'])) // after registered...
    {
        header('location: index.php');
        exit;
    }

    // registration page
    if(isset($_POST['register']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm = $_POST['confirm'];

        if($password !== $confirm)
        {
            header("location: login.php?error=password doesn't match"); 
        }

        else if(strlen($password < 6))
        {
            header("location: login.php?error=password should be at least 6 characters.");
        }

            // if there is no error,
        else{

                //check whether the same user using the same email
                $stmt1 = $conn->prepare("SELECT count(*) FROM users where user_email=?");
                $stmt1->bind_param('s',$email);
                $stmt1->execute();

                $stmt1->bind_result($num_rows);
                $stmt1->store_result();
                $stmt1->fetch();

                //if there is a user already registered with this email.
                if($num_rows != 0 )
                {
                    header('location: login.php?error=user with this email already exists.');
                }
                else{  //if no user is register with email before

                        //create a new user 
                        $stmt = $conn->prepare("INSERT INTO users (user_name,user_email,user_password)
                        VALUES (?,?,?); "); // get more secure...

                        $stmt-> bind_param($name,$email,md5($password)); //hash the password that turns the password into text that including encrypted algorithms


                        //if the user registered successfully
                        if($stmt->execute())
                        {
                            $_SESSION['user_email'] = $email;
                            $_SESSION['user_name'] = $name;
                            $_SESSION['logged_in'] = true;
                            header('location: index.php?register= you are successfully registered!');
                        }
                        else // couldn't registered successfully
                        {
                            header("location: index.php?register= you didn't successfully registered!");
                        }
                }

        }

    }
    

    //login page
    if(isset($_POST['signin']))
    {
        $email = $_POST['email1'];
        $password = md5($_POST['password1']);

        $stmt2 = $conn->prepare("SELECT user_id,user_name,user_email,user_password FROM users where user_email=? and user_password = ?
                        LIMIT 1 "); // get more secure...

        $stmt2->bind_param('ss',$email,$password);

        if($stmt2->execute())
        {
            $stmt2->bind_result($user_id,$user_name,$user_email,$user_password);
            $stmt2->store_result();

            if($stmt2-> num_rows() == 1)
            {
                $row = $stmt2->fetch();

                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $user_name;
                $_SESSION['user_email'] = $user_email;
                $_SESSION['logged_in'] = true;
                header('location: index.php?message= you are successfully logged in!');
            }
            else
            {
                header("location: login.php?login=couldn't verify your account");
            }
        }
        else{
            header("location: login.php?login=something went wrong");
        }


    }

?>



<html>
    <head>
        <title>E-painting</title>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"/>
        <script src="https://kit.fontawesome.com/c4a594ff55.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="first.css">
    </head>
    <body>
        <section id = "header">
            <a href="#"> <img src="logo/download (2).png" class = "logo" alt="" style="max-width: 20%"></a>
            <div>
                <ul id="navbar"> 
                    <li><a  href="index.php" >Home</a></li>
                    <li><a  href="shop.html">Shop</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a  href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a class="active"  href="login.html">login</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </section>

        <div class="form-box">
            <div class="button-box">
                    <div id="btn"></div>
                        <button type="button" class="login" id="login-btn">Log in</button>
                        <button type="button" class="login" id="signup-btn">Sign up</button>
            </div>
            <div class="social-icons">
                <i class="fa-brands fa-facebook"></i>
                <i class="fa-brands fa-google"></i>
                <i class="fa fa-instagram" aria-hidden="true"></i>
            </div>
            <form id="login" class="input-group" method="post" action="login.php">
                <p style="color: black; font-size: 15px;"><?php if(isset($_GET['login'])){ echo $_GET['login']; } ?></p>
                <input type="email" class="input-field" placeholder="Your e-mail" name="email1">
                <input type="password" class="input-field" placeholder="password" name="password1" required>
                <div>
                    <input type="checkbox" class="check-box"><span>Remember password</span>
                </div>
                <button type="submit" class="normal" name="signin">Log in</button>
            </form>
            <form id="signup" class="input-group" method="post" action="login.php">
                <input type="text" class="input-field" name="name" placeholder="Your name">
                <input type="email" class="input-field" name="email" placeholder="Your e-mail">
                <input type="password" class="input-field" name="password" placeholder="password" required>
                <input type="password" class="input-field" name="Confirm" placeholder="Confirm password" required>
                <div>
                    <p style="color: black; font-size: 15px;"><?php if(isset($_GET['error'])){  echo $_GET['error']; } ?></p>
                    <input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>
                </div>
                <button type="submit" name="register" class="normal">Sign up</button>
            </form>
        </div>

        <footer class="section-p1">
            <div class="col">
                <a href="#"> <img class = "logo" src="logo/download (2).png" class = "logo" alt="" style="max-width: 15%"></a>
                <h4>Contact</h4>
                <p><strong>Phone: </strong> +61 1300 002 340</p>
                <p><strong>Email: </strong> info@epainting.com.lk</p>
                <div class="follow">
                    <h4>follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                        <i class="fa fa-pinterest-square" aria-hidden="true"></i>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col-flex">
                <div class="col">
                    <h4>About</h4>
                    <a href="#" onclick="window.location.href='about.html';">About us</a>
                    <a href="#">Delivery & Refunds</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms & conditions</a>
                    <a href="#" onclick="window.location.href='contact.html';">Contact us</a>
                </div>
                <div class="col">
                    <h4>My Account</h4>
                    <a href="#" onclick="window.location.href='login.html';">Login</a>
                    <a href="#" onclick="window.location.href='cart.html';">View Cart</a>
                    <a href="#">Help</a>
                </div>
                <div class="col install">
                   <h4>Secured Payment Gateways</h4>
                   <img src="logo/pay4-removebg-preview.png" alt="" style="max-width: 30%">
                   
                </div>
            </div>
        </footer>

        <script>

            signUpButton = document.getElementById("signup-btn")
            const loginButton = document.getElementById("login-btn")
            const loginForm = document.getElementById("login")
            const signUpForm = document.getElementById("signup")

            loginButton.style.backgroundColor = "#a816ebc2"

            signUpButton.addEventListener("click", () => {
                signUpButton.style.backgroundColor = "#a816ebc2";
                loginButton.style.backgroundColor = "transparent";
                signUpForm.style.display = "flex"
                loginForm.style.display = "none"
            })

            loginButton.addEventListener("click", () => {
               signUpButton.style.backgroundColor = "transparent";
               loginButton.style.backgroundColor = "#a816ebc2";
               signUpForm.style.display = "none"
               loginForm.style.display = "flex"
           })

            // var x = document.getElementById("login");
            // var y = document.getElementById("signup");
            // var z = document.getElementById("btn");

            // function register()
            // {
            //     x.style.left = "-400px";
            //     y.style.left = "50px";
            //     z.style.left = "50px";
            // }

            // function login()
            // {
            //     x.style.left = "50px";
            //     y.style.left = "450px";
            //     z.style.left = "0px";
            // }
        </script>

        <script src="first.js"></script>
    </body>
    
</html>