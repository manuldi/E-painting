<?php
session_start();

if(isset($_POST['add_to_cart']))
{
    echo '<script> alert{"successfully"}; </script>';
    //if user has a already added a product to the cart.
    if(isset($_SESSION['cart']))
    {
        $products_array_name = array_column($_SESSION['cart'], "product_name"); // return products in array cart.
        //if the product is already added to the cart or not.
        if(!in_array($_POST['product_name'], $products_array_name))
        { 
                $product_name = $_POST['product_name'];
            
                $product_array = array(
                                'product_img' => $_POST['product_img'],
                                'product_name' => $_POST['product_name'],
                                'product_price' => $_POST['product_price'],
                                'product_quantity' => $_POST['product_quantity']
                );
        
                $_SESSION['cart'] [$product_name] = $product_array;
        }
        //product has already added!
        else{
            echo '<script> alert{"product has already added!"}; </script>';
            //echo '<script> window.location = "index.php" ; </script>';
        }
    }
    // this is the first product.
    else{
        $product_img = $_POST['product_img'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_quantity = $_POST['product_quantity']; 
        
        $product_array = array(
                        'product_img' => $product_img,
                        'product_name' => $product_name,
                        'product_price' => $product_price,
                        'product_quantity' => $product_quantity
        );

        //to add more products - [ name1=>[name1], name2=>[name2],]
        $_SESSION['cart'] [$product_name] = $product_array;
    }
    // update the total
    calculateTotal();

}
// remove products from cart
elseif(isset($_POST['remove_product']))
{
    $product_name = $_POST['product_name'];
    unset($_SESSION['cart'] [$product_name]);

    // update the total
    calculateTotal();

}
// edit quantity
elseif(isset($_POST['edit_quantity']))
{
    $product_name = $_POST['product_name'];
    $product_quantity = $_POST['product_quantity'];

    // get product array from the session
    $product_array = $_SESSION['cart'] [$product_name];
    //new value is assign to old array.
    $product_array['product_quantity'] = $product_quantity;

    //return array back to its place
    $_SESSION['cart'] [$product_name] = $product_array;

    // update the total
    calculateTotal();

}else{
    //header('location: index.php');
}

function calculateTotal()
{
    $total = 0;

    foreach ($_SESSION ['cart'] as $key => $value)
    {
        $product = $_SESSION['cart'] [$key];

        $price = $product['product_price'];
        $quantity = $product['product_quantity'];

        $total = $total + ($price * $quantity);
    }

    $_SESSION['total'] = $total;
};
?>


<html>
    <head>
        <title>E-painting</title>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"/>
        <script src="https://kit.fontawesome.com/c4a594ff55.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="first.css">
    </head>
    <body>
        <section id = "header">
            <a href="#"> <img src="logo/download (2).png" class = "logo" alt="" style="max-width: 20%"></a>
            <div>
                <ul id="navbar"> 
                    <li><a  href="index.php" >Home</a></li>
                    <li><a  href="shop.html">Shop</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a  href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.php">login</a></li>
                    <li><a class="active" href="cart.html"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </section>

        <section id="page-header" class="about-header">
            <h2 >Your wall painting is waiting for you.</h2>
            <p>Checkout now</p>
        </section>

        <section id="cart" class="section-p1">
            <table width = "100%">
                <thead>
                    <tr>
                        <td>Remove</td>
                        <td>Image</td>
                        <td>Product</td>
                        <td>Price</td>
                        <td>Quantity</td>
                        <td>Subtotal</td>
                    </tr>
                </thead>
                <tbody>
                    <?php 

                        foreach ($_SESSION['cart'] as $key => $value)
                        { ?>

                        
                    
                    <tr>
                        <form method="POST" action="cart.php">
                            <input type="hidden" name="product_name" value="<?php echo $value ['product_name']; ?>"/>
                            <td> <input type="submit" name="remove_product" value="remove" class="remove"> </td>
                            <!-- <td><a href="#" ><i class="fa-solid fa-xmark" name = "remove_product"> </i> </a></td> -->
                        </form>
                        <td><img src="products/<?php echo $value ['product_img']; ?>"></td>
                        <td><?php echo $value ['product_name']; ?></td>
                        <td><?php echo $value ['product_price']; ?></td>
                        
                        <td>
                            <form method="post" action="cart.php">
                                <input type="hidden" name="product_name" value="<?php echo $value ['product_name']; ?>"/>
                                <input type="number"  name="product_quantity" value="<?php echo $value ['product_quantity']; ?> "/>
                                <br>
                                <input type="submit" name="edit_quantity" value="edit" class="edit"/>
                            
                            </form>
                        </td>
                        
                        

                        <td><span>Rs.</span><?php echo $value ['product_quantity'] * $value ['product_price']; ?></td>
                    </tr>

                    <?php } ?>
                    <!-- <tr>
                        <td><i class="fa-solid fa-xmark"> <a href="#"> </a></i></td>
                        <td><img src="products/new3.webp"></td>
                        <td>Art Elevation</td>
                        <td>Rs.4999</td>
                        <td><input type="text" value="1"></td>
                        <td>Rs.4999</td>
                    </tr>
                    <tr>
                        <td><i class="fa-solid fa-xmark"> <a href="#"> </a></i></td>
                        <td><img src="products/new4.webp"></td>
                        <td>War Paint</td>
                        <td>Rs.7499</td>
                        <td><input type="text" value="1"></td>
                        <td>Rs.7499</td>
                    </tr> -->
                </tbody>
            </table>
        </section>

        <section id="cart-add" class="row">
            <div id="coupon">
            </div>
            <div id="subtotal">
                <h3>Cart Totals</h3>
                <table>
                    <tr>
                        <td>Cart Subtotal</td>
                        <td><strong>Rs.</strong> <?php echo $_SESSION['total']; ?></td>
                    </tr>
                    <tr>
                        <td>Shipping</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td><strong>Total</strong></td>
                        <td><strong>Rs.</strong> <?php echo $_SESSION['total']; ?></td>
                    </tr>
                </table>
                <form method="post" action="checkout.php">
                        <input type="submit" class="checkout" value="Proceed to Checkout" name="checkout"></button>
                </form>
                
            </div>
        </section>

        <footer class="section-p1">
            <div class="col">
                <a href="#"> <img class = "logo" src="logo/download (2).png" class = "logo" alt="" style="max-width: 15%"></a>
                <h4>Contact</h4>
                <p><strong>Phone: </strong> +61 1300 002 340</p>
                <p><strong>Email: </strong> info@epainting.com.lk</p>
                <div class="follow">
                    <h4>follow us</h4>
                    <div class="icon">
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                        <i class="fa fa-pinterest-square" aria-hidden="true"></i>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col-flex">
                <div class="col">
                    <h4>About</h4>
                    <a href="#" onclick="window.location.href='about.html';">About us</a>
                    <a href="#">Delivery & Refunds</a>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms & conditions</a>
                    <a href="#" onclick="window.location.href='contact.html';">Contact us</a>
                </div>
                <div class="col">
                    <h4>My Account</h4>
                    <a href="#" onclick="window.location.href='login.html';">Login</a>
                    <a href="#" onclick="window.location.href='cart.html';">View Cart</a>
                    <a href="#">Help</a>
                </div>
                <div class="col install">
                   <h4>Secured Payment Gateways</h4>
                   <img src="logo/pay4-removebg-preview.png" alt="" style="max-width: 30%">
                   
                </div>
            </div>
        </footer>
        <script src="first.js"></script>
    </body>
    
</html>