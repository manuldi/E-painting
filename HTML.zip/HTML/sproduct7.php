<html>
    <head>
        <title>E-painting</title>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"/>
        <script src="https://kit.fontawesome.com/c4a594ff55.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="first.css">
    </head>
    <body>
 
        <section id = "header">
            <a href="#"> <img src="logo/download (2).png" class = "logo" alt="" style="max-width: 20%"></a>
            <div>
                <ul id="navbar"> 
                    <li><a  href="index.php" >Home</a></li>
                    <li><a class="active"  href="shop.html">Shop</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.html">login</a></li>
                    <li><a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </section>

        <section id="prodetails" class="section-p1">
            <div class="single-pro-image">
                <img src="products/new7.webp" width="100%" id="MainImg" alt="">

                <div class="small-img-group">
                    <div class="small-img-col">
                        <img src="products/new7.webp" width="100%" class= "small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="products/new72.webp" width="100%" class= "small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="products/new73.webp" width="100%" class= "small-img" alt="">
                    </div>
                    <div class="small-img-col">
                        <img src="products/new73.webp" width="100%" class= "small-img" alt="">
                    </div>
                </div>
            </div>

            <div class="single-pro-details">
                <h4>Big Flashy Light Bridge</h4>
                <h2>Rs.14999</h2>
                <select>
                    <option>Select size</option>
                    <option>140 X 70</option>
                    <option>180 X 80</option>
                    <option>100 X 100</option>
                    <option>120 X 60</option>
                </select>

                <?php 
                    $product_img = "products/new7.webp";
                    $product_name = "Big Flashy Light Bridge";
                    $product_price = 14999;
                    $product_quantity = 1;
                    
                ?>
                <form method="post" action="cart.php">
                    <input type="hidden" name = "product_img" value= "<?php echo $product_img;?>"/>
                    <input type="hidden" name = "product_name" value= "<?php echo $product_name;?>"/>
                    <span>Rs.</span><input type="hidden" name = "product_price" value= "<?php echo $product_price;?>"/>
                    <input type="number" name = "product_quantity" value="<?php echo $product_quantity;?>">
                    <button class = "normal" type="submit" name="add_to_cart">Add To Cart</button>
                </form>
                <br>
                <span>The mix of clean and clearly painted sky and thick, colour rich colours of the city lights is making Big Flashy Light Bridge an impressive city landscape painting. There are additional details, like the powerful vibrant colours mirrored in the ocean, that makes it a special urban art piece that displays the beauty of the bridges and the architecture. </span>
                <p>
                    <br>
                    <strong>Specifications</strong>
                    <br>
                    • Oil Painting on canvas
                    <br>
                    • 100% Hand Painted
                    <br>
                    • Gallery Wrap & stretched on wood frame Ready-to-Hang
                    <br>
                    • Available in Horizontal Orientation
                    <br>
                    • 1xPainting in Secure Packaging box
                    <br>
                    • Leaves  Warehouse in 2-3 Days
                    <br>
                    • Delivery All over the world
                </p>
            </div>
        </section>

        <section id="product2" class="section-p1">
            <h2>New arrivals</h2>
            <div class="pro-container">
                <div class="pro">
                    <img src="products/product6.jpg" alt="">
                    <div class="des">
                        <h5>Framed prints</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>$899</h4>
                    </div>
                    <a href="#"><i class="fal fa-shopping-cart"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product17.jpg" alt="">
                    <div class="des">
                        <h5>Follow the light</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>$699</h4>
                    </div>
                    <a href="#"><i class="fal fa-shopping-cart"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product15.webp" alt="">
                    <div class="des">
                        <h5>Hidden Fairy Of Colors</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>$499</h4>
                    </div>
                    <a href="#"><i class="fal fa-shopping-cart"></i></a>
                </div>
                <div class="pro">
                    <img src="products/product16.jpg" alt="">
                    <div class="des">
                        <h5>Winter Lake</h5>
                        <div class = "star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4>$349</h4>
                    </div>
                    <a href="#"><i class="fal fa-shopping-cart"></i></a>
                </div>
            </div>
        </section>

        <section id ="newsletter" class="section-p1">
            <div class = "newstext">
                <h4>Sign up for Newsletters</h4>
                <p>Get E-mail updates about latest shop and <span> special offers.</span></p>
            </div>
            <div class ="form">
                <button class="normal">Sign up</button>
            </div>
        </section>

        <footer class="section-p1">
            <div class="col">
                <a href="#"> <img class = "logo" src="logo/download (2).png" class = "logo" alt="" style="max-width: 15%"></a>
                <h4>Contact</h4>
                <p><strong>Phone: </strong> +61 1300 002 340</p>
                <p><strong>Email: </strong> info@epainting.com.lk</p>
                <div class="follow">
                    <h4>follow us</h4>
                    <div class="icon">
                        <i class="fa fa-facebook-official" aria-hidden="true"></i>
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                        <i class="fa fa-pinterest-square" aria-hidden="true"></i>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </div>
            </div>
            <div class="col">
                <h4>About</h4>
                <a href="#">About us</a>
                <a href="#">Delivery & Refunds</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & conditions</a>
                <a href="#">Contact us</a>
            </div>
            <div class="col">
                <h4>My Account</h4>
                <a href="#">Sign in</a>
                <a href="#">View Cart</a>
                <a href="#">Track My Order</a>
                <a href="#">Help</a>
            </div>
            <div class="col install">
               <h4>Secured Payment Gateways</h4>
               <img src="logo/pay4-removebg-preview.png" alt="" style="max-width: 30%">
               
            </div>
        </footer>

        <script>
            let MainImg = document.getElementById("MainImg");
            let SmallImg = document.getElementsByClassName("small-img");

            SmallImg[0].onclick = function()
            {
                MainImg.src = SmallImg[0].src;
            }
            SmallImg[1].onclick = function()
            {
                MainImg.src = SmallImg[1].src;
            }
            SmallImg[2].onclick = function()
            {
                MainImg.src = SmallImg[2].src;
            }
            SmallImg[3].onclick = function()
            {
                MainImg.src = SmallImg[3].src;
            }
        </script>

        <script src="first.js"></script>
    </body>
    
</html>